package project.org;

import java.util.*;

public class Book {
	Scanner in =new Scanner(System.in);
	String tittle;
	String author;
	String isbn;
	String genre;
	boolean availablity;
	Book(){
		
	}
	Book(String t,String a,String i,String g){
		tittle=t;
		author=a;
		isbn=i;
		genre=g;
	}
	Book(String h)throws Exception{
		System.out.println("Enter the Tittle");
		tittle=in.nextLine();
		System.out.println("Enter Name of author");
		author=in.nextLine();
		System.out.println("Enter ISBN No");
		isbn=in.nextLine();
		System.out.println("Enter Genre of the book");
		genre=in.nextLine();
		
	}
	public void display() {
		System.out.println("Tittle: "+tittle);
		System.out.println("Author: "+author);
		System.out.println("ISBN No: "+isbn);
		System.out.println("Genre: "+genre);
		
	}

}
/*class Science extends Book{
	String Category="Science Fiction";
}
*/
