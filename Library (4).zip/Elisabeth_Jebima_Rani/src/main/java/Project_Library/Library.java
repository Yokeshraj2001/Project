package Project_Library;
import java.util.*;
public class Library extends Book {
	public static ArrayList<Book>books=new ArrayList<Book>();{
	 Book b1=new Book("Yokeshraj","O","3","E",5);
	 Book b2=new Book("MrFreakz","K","3","E",5);
	 Book b3=new Book("Elisabeth","E","3","E",5);
	 Book b4=new Book("jebima","S","3","E",5);
	 Book b5=new Book("rani","H","3","E",5);
	 books.add(0, b1);
	 books.add(1, b2);
	 books.add(2, b3);
	 books.add(3, b4);
	 books.add(4, b5);}
	 Scanner in =new Scanner(System.in);
public void addBook() throws Exception{
		 char opt='A',opt1='D';
		 if (books.size()%5==0) {
			 System.out.println("Added Books  "+books.size()+" if you want to continue press Y else press N");
			 opt=in.next().toUpperCase().charAt(0);
	          opt1=(opt=='Y')?'Y':'N';}
		 if(opt1=='Y'||books.size()%5!=0) {
         		Book b1=new Book("");
                books.add(b1);}
         if(opt1=='N') {
        	 System.out.println("Thank You for Adding Book");
        	 return;}}
 public void print(){
	System.out.println("//////Books in the Library////// ");int i=1;
		for(Book bb:books) {
			System.out.println("S.No: "+i);
			System.out.println("Tittle: "+bb.tittle);
			System.out.println("Author: "+bb.author);
			System.out.println("ISBN No: "+bb.isbn);
			System.out.println("Genre: "+bb.genre);
			System.out.println("Number of Copies in Library :"+bb.count);
			System.out.println("***********");
			i++;
			try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
		}}
 public void available(String needbook) {
	int n=0;
 	for(Book bs:Library.books) {
 		if(needbook.equals(bs.tittle)) {
 			if(bs.count>0) {
 			 System.out.println("Congrats!!! Book is available in the library");
 	 		n=bs.count--;
 	 		System.out.println(n-1);}
 			else {
 				System.out.println("Books Not in stock");
 			}}}
 	   System.out.println("You Entered Book is not available in the library");
  }
 }
